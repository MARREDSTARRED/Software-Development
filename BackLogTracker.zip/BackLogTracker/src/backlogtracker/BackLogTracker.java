
package backlogtracker;

/**
 * @McKayARobison
 * 
 */
import java.util.Arrays;
import java.util.Scanner;
import java.io.FileWriter;
public class BackLogTracker {

    
    public static void main(String[] args) {
Scanner input = new Scanner(System.in);     
    //Opening Statements
    
    System.out.println("Hello my Name is Backlog Bard ");
    
    System.out.println("Let's track your weekly progress! ");
    System.out.print("Enter Quit, or Enter List: ");
    //Closing of Opening Statements
    String usAn= input.nextLine();
    
    //User types list it move to printList  
        if (usAn.equalsIgnoreCase("List")){
            printList();}
    //User types quit it ends
        if (usAn.equalsIgnoreCase("Quit")){
          
            
            
        }
    
    }
    public static void printList(){
    Scanner input = new Scanner(System.in);
    //List Array    
        String[] list = new String[5]; 
    //Time Array
        String[] time = new String[5];
    //Counts for the Game List   
    int count = 0;
    // Counts for the Time List
    int countD = 0;
        System.out.println("We will be adding Five games to our list!");
    System.out.printf("Remember \"How do you eat a elephant\" ");
    System.out.printf("\"One Bite At A Time\"");
    //Counts to five times for strings then moves on
    for (int i = 0; i<list.length; i++){
     count++;
        System.out.printf("%nWhat is game "+count+"? ");
      list[i] = input.nextLine();
    }
    System.out.println("Alright time to track your progress for the period");
    //Counts to five hours then moves on    
    for (int e = 0; e<list.length; e++){
            countD++;
            System.out.printf("How much time did you spend on game "+countD+"? "
                    + "%nEnter it in hours rounded to the nearest whole: ");
            time[e] = input.nextLine();
        
        }
    //Counts the array list of both printing out each pairing one   
    for (int i = 0; i<list.length; i++)
           
           System.out.println("You played "+list[i]+" for "+ time[i]+" Hours");
       
       
    
    }
}


